"use client";

import { FormEvent, useEffect, useState } from "react";
import { API, api } from "../lib/api";

type Column = { name: string; data_type: "string" | "integer" | "number" | "boolean"; description: string; required: boolean; allowed_values: string[] };
type Spec = { dataset_type: string; languages: string[]; columns: Column[]; constraints: string[] };
type Dataset = { id: string; name: string; status: string; created_at: string };
type Version = { id: string; version_number: number; record_count: number; quality_report: { quality_score?: number } };

const initialPrompt = "Generate 100 customer support conversations for an Indian banking app. Include customer queries, agent responses, intent, sentiment, and resolution status in English and Hindi.";

export default function Home() {
  const [token, setToken] = useState<string | null>(null);
  const [email, setEmail] = useState("demo@dataforge.local");
  const [password, setPassword] = useState("ChangeMe12345!");
  const [prompt, setPrompt] = useState(initialPrompt);
  const [spec, setSpec] = useState<Spec | null>(null);
  const [count, setCount] = useState(100);
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [message, setMessage] = useState("Create an account or sign in to begin.");

  useEffect(() => { const stored = localStorage.getItem("dataforge_access_token"); if (stored) { setToken(stored); void loadDatasets(stored); } }, []);

  async function authenticate(event: FormEvent, mode: "login" | "register") {
    event.preventDefault();
    try {
      const result = await api<{ access_token: string }>(`/auth/${mode}`, { method: "POST", body: JSON.stringify({ email, password }) });
      localStorage.setItem("dataforge_access_token", result.access_token); setToken(result.access_token); await loadDatasets(result.access_token); setMessage(`Signed in as ${email}.`);
    } catch (error) { setMessage((error as Error).message); }
  }
  async function loadDatasets(activeToken = token) { if (!activeToken) return; try { setDatasets(await api<Dataset[]>("/datasets", {}, activeToken)); } catch (error) { setMessage((error as Error).message); } }
  async function analyze() { if (!token) return setMessage("Sign in before analyzing a prompt."); try { const result = await api<{ specification: Spec; suggested_record_count: number }>("/prompts/analyze", { method: "POST", body: JSON.stringify({ prompt, record_count: count }) }, token); setSpec(result.specification); setCount(result.suggested_record_count); setMessage("Schema proposed. Review it, then generate your dataset."); } catch (error) { setMessage((error as Error).message); } }
  async function createAndGenerate() {
    if (!token || !spec) return setMessage("Sign in and analyze a prompt first.");
    try {
      const dataset = await api<Dataset>("/datasets", { method: "POST", body: JSON.stringify({ name: `${spec.dataset_type.replaceAll("_", " ")} dataset`, description: prompt, specification: spec }) }, token);
      const job = await api<{ status: string; generated_records: number }>(`/datasets/${dataset.id}/generate`, { method: "POST", body: JSON.stringify({ record_count: count }) }, token);
      setMessage(`Generation ${job.status}: ${job.generated_records} records created.`); await loadDatasets();
    } catch (error) { setMessage((error as Error).message); }
  }
  async function inspect(dataset: Dataset) {
    if (!token) return; try { const versions = await api<Version[]>(`/datasets/${dataset.id}/versions`, {}, token); const version = versions[0]; if (!version) return setMessage("This dataset has no completed version yet."); setMessage(`Version ${version.version_number}: ${version.record_count} records; quality score ${version.quality_report.quality_score ?? "pending"}/100. Download: ${API}/dataset-versions/${version.id}/export?format=csv (use authenticated API client in production).`); } catch (error) { setMessage((error as Error).message); }
  }

  return <main>
    <header><div><span className="mark">DF</span><b>DataForge AI</b></div><p>Prompt-to-dataset generation platform</p></header>
    <p className="notice" role="status">{message}</p>
    {!token && <section className="auth"><h1>Build trustworthy synthetic datasets</h1><p>Start with a natural-language request, review the schema, and generate versioned data with quality checks.</p><form><input value={email} onChange={e => setEmail(e.target.value)} type="email" aria-label="Email" /><input value={password} onChange={e => setPassword(e.target.value)} type="password" aria-label="Password" /><div><button onClick={e => authenticate(e, "login")}>Sign in</button><button className="secondary" onClick={e => authenticate(e, "register")}>Create account</button></div></form></section>}
    {token && <div className="workspace"><section className="studio"><p className="eyebrow">PROMPT STUDIO</p><h1>Describe the dataset you need</h1><textarea value={prompt} onChange={e => setPrompt(e.target.value)} rows={8} /><label>Records <input type="number" min="1" max="100000" value={count} onChange={e => setCount(Number(e.target.value))} /></label><button onClick={analyze}>Analyze prompt</button></section>
      <section className="schema"><p className="eyebrow">GENERATION PLAN</p><h2>{spec ? spec.dataset_type.replaceAll("_", " ") : "Awaiting analysis"}</h2>{spec ? <><p>Languages: {spec.languages.join(", ")}</p><ul>{spec.columns.map(column => <li key={column.name}><code>{column.name}</code><span>{column.data_type} · {column.description}</span></li>)}</ul><button onClick={createAndGenerate}>Generate {count.toLocaleString()} records</button></> : <p>Analyze a prompt to produce an editable, typed specification.</p>}</section></div>}
    {token && <section className="datasets"><div><p className="eyebrow">DATASETS</p><h2>Your generation history</h2></div>{datasets.length ? <ul>{datasets.map(dataset => <li key={dataset.id}><div><b>{dataset.name}</b><span>{dataset.status} · {new Date(dataset.created_at).toLocaleDateString()}</span></div><button className="secondary" onClick={() => inspect(dataset)}>Inspect</button></li>)}</ul> : <p>No datasets yet.</p>}</section>}
  </main>;
}
