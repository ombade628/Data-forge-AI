import csv
import json
from pathlib import Path
from uuid import UUID
from openpyxl import Workbook
from app.core.config import get_settings


def build_export(version_id: UUID, records: list[dict], export_format: str) -> Path:
    if export_format not in {"csv", "json", "jsonl", "xlsx"}:
        raise ValueError("format must be csv, json, jsonl, or xlsx")
    directory = get_settings().export_directory
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{version_id}.{export_format}"
    columns = list(records[0].keys()) if records else []
    if export_format == "json":
        path.write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
    elif export_format == "jsonl":
        path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in records), encoding="utf-8")
    elif export_format == "csv":
        with path.open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=columns)
            writer.writeheader()
            writer.writerows(records)
    else:
        workbook = Workbook()
        sheet = workbook.active
        sheet.append(columns)
        for row in records:
            sheet.append([row.get(column) for column in columns])
        workbook.save(path)
    return path
