from uuid import UUID
from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import func, select
from app.api.deps import CurrentUser, DbSession
from app.db.models import Dataset, DatasetVersion
from app.domains.quality.service import evaluate_records
from app.schemas import DatasetCreate, DatasetRead, DatasetSpecification, DatasetVersionRead

router = APIRouter(prefix="/datasets", tags=["datasets"])


async def owned_dataset(dataset_id: UUID, user: CurrentUser, db: DbSession) -> Dataset:
    dataset = await db.scalar(select(Dataset).where(Dataset.id == dataset_id, Dataset.owner_id == user.id))
    if not dataset:
        raise HTTPException(status_code=404, detail="Dataset not found")
    return dataset


@router.post("", response_model=DatasetRead, status_code=status.HTTP_201_CREATED)
async def create_dataset(payload: DatasetCreate, user: CurrentUser, db: DbSession):
    dataset = Dataset(owner_id=user.id, name=payload.name, description=payload.description, specification=payload.specification.model_dump(mode="json"))
    db.add(dataset)
    await db.commit()
    await db.refresh(dataset)
    return dataset


@router.get("", response_model=list[DatasetRead])
async def list_datasets(user: CurrentUser, db: DbSession, limit: int = Query(20, ge=1, le=100), offset: int = Query(0, ge=0)):
    return (await db.scalars(select(Dataset).where(Dataset.owner_id == user.id).order_by(Dataset.created_at.desc()).offset(offset).limit(limit))).all()


@router.get("/{dataset_id}", response_model=DatasetRead)
async def get_dataset(dataset_id: UUID, user: CurrentUser, db: DbSession):
    return await owned_dataset(dataset_id, user, db)


@router.get("/{dataset_id}/versions", response_model=list[DatasetVersionRead])
async def list_versions(dataset_id: UUID, user: CurrentUser, db: DbSession):
    await owned_dataset(dataset_id, user, db)
    return (await db.scalars(select(DatasetVersion).where(DatasetVersion.dataset_id == dataset_id).order_by(DatasetVersion.version_number.desc()))).all()


@router.get("/{dataset_id}/versions/{version_id}/records")
async def preview_records(dataset_id: UUID, version_id: UUID, user: CurrentUser, db: DbSession, limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0)):
    await owned_dataset(dataset_id, user, db)
    version = await db.scalar(select(DatasetVersion).where(DatasetVersion.id == version_id, DatasetVersion.dataset_id == dataset_id))
    if not version:
        raise HTTPException(status_code=404, detail="Dataset version not found")
    return {"items": version.records[offset:offset + limit], "total": version.record_count}


@router.patch("/{dataset_id}/versions/{version_id}/records/{record_index}", response_model=DatasetVersionRead)
async def edit_record(dataset_id: UUID, version_id: UUID, record_index: int, payload: dict, user: CurrentUser, db: DbSession):
    """Edit by creating a new immutable version rather than changing historical output."""
    dataset = await owned_dataset(dataset_id, user, db)
    source = await db.scalar(select(DatasetVersion).where(DatasetVersion.id == version_id, DatasetVersion.dataset_id == dataset.id))
    if not source or not 0 <= record_index < len(source.records):
        raise HTTPException(status_code=404, detail="Record not found")
    if not isinstance(payload, dict):
        raise HTTPException(status_code=422, detail="Record must be a JSON object")
    records = [*source.records]
    records[record_index] = payload
    spec = DatasetSpecification.model_validate(source.schema_definition)
    allowed = {column.name for column in spec.columns}
    if set(payload) != allowed:
        raise HTTPException(status_code=422, detail=f"Record fields must exactly match: {', '.join(sorted(allowed))}")
    latest_number = await db.scalar(select(func.max(DatasetVersion.version_number)).where(DatasetVersion.dataset_id == dataset.id))
    version = DatasetVersion(dataset_id=dataset.id, version_number=(latest_number or 0) + 1, schema_definition=source.schema_definition, records=records, record_count=len(records), quality_report=evaluate_records(records, spec))
    db.add(version)
    await db.commit()
    await db.refresh(version)
    return version
