import uuid
from sqlalchemy import select
from app.ai.providers.factory import get_dataset_provider
from app.db.models import Dataset, DatasetVersion, GenerationJob
from app.db.session import SessionLocal
from app.domains.quality.service import evaluate_records
from app.schemas import DatasetSpecification


async def run_generation_job(job_id: str) -> None:
    """Run one idempotent job. Celery calls this function; inline development does too."""
    async with SessionLocal() as db:
        job = await db.get(GenerationJob, uuid.UUID(job_id))
        if not job or job.status in {"completed", "cancelled"}:
            return
        dataset = await db.get(Dataset, job.dataset_id)
        if not dataset:
            job.status, job.error_message = "failed", "Dataset no longer exists"
            await db.commit()
            return
        try:
            job.status = "running"
            dataset.status = "generating"
            await db.commit()
            specification = DatasetSpecification.model_validate(dataset.specification)
            provider = get_dataset_provider()
            records = provider.generate(specification, job.requested_records, seed=job.id.int % 2**32)
            quality = evaluate_records(records, specification)
            latest = await db.scalar(select(DatasetVersion.version_number).where(DatasetVersion.dataset_id == dataset.id).order_by(DatasetVersion.version_number.desc()).limit(1))
            version = DatasetVersion(
                dataset_id=dataset.id,
                version_number=(latest or 0) + 1,
                schema_definition=specification.model_dump(mode="json"),
                records=records,
                record_count=len(records),
                quality_report=quality,
            )
            db.add(version)
            job.status = "completed"
            job.generated_records = len(records)
            job.usage = {"provider": provider.name, "model": job.model_name, "estimated_tokens": 0, "estimated_cost_usd": 0}
            dataset.status = "ready"
            await db.commit()
        except Exception as exc:  # keep actionable failure state for the user
            job.status, job.error_message = "failed", str(exc)[:1000]
            dataset.status = "failed"
            await db.commit()
            raise
